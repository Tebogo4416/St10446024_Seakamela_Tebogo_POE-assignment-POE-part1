
package tebo.account;


public class Tasks {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
    
    // Task properties are initialised using the constructor.
    public Tasks(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus){
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }
    
    // Verify that the task description is no more than 50 characters.
    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }
    
    // Create a distinct Task ID. 
    public String createTaskID() {
        return taskName.substring(0,2).toUpperCase() + ":" +
                taskNumber + ":" +
                developerDetails.substring(developerDetails.length()- 3).toUpperCase(); 
    }
    // How to print the assignment details
    public String printTaskDetails() {
        return "Task Status:" + taskStatus +
                "\nDeveloper:" + developerDetails +
                "\nTask Number:" + taskNumber + 
                "\nTask Description:" + taskDescription +
                "\nTask ID:" + taskID +
                "\nDuration:" + taskDuration + "hours";
    }
    
    // Task duration getter (used to determine total hours)
    public int getTaskDuration() {
        return taskDuration;
    }
}
