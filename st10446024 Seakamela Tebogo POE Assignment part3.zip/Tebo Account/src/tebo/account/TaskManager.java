package tebo.account;
import java.util.ArrayList;
import java.util.Scanner;

public class TaskManager {
    public String[] getDevelopers() { 
    return developers; 
}

public String[] getTaskNames() { 
    return taskNames; 
}

public String[] getTaskIDs() { 
    return taskIDs; 
}

public int[] getTaskDurations() { 
    return taskDurations; 
}

public String[] getTaskStatuses() { 
    return taskStatuses; 
}

public int getTaskCount() { 
    return taskCount; 
}

    // Array to store task details
    public String[] developers = new String[10];
    public String[] taskNames = new String[10];
    public String[] taskIDs = new String [10];
    public int[] taskDurations = new int[10];
    public String[] taskStatuses = new String[10];
    public int taskCount = 0;
    
    public TaskManager() {
        
        // Arrays are automatically initialized in Java, so no extra initialization is required
    }
    public void addTask(String developer, String taskName, int taskDuration, String taskStatus) {
        if (taskCount < developers.length) {
            developers[taskCount] = developer;
            taskNames[taskCount] = taskName;
            taskDurations[taskCount] = taskDuration;
            taskStatuses[taskCount] = taskStatus;
            
            String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskCount + ":" + developer.substring(developer.length() - 3).toUpperCase();
            taskIDs[taskCount] = taskID;
            
            taskCount++;
            System.out.println("Task added successfully!");
        }else {
            System.out.println("Task list is full. Cannot add more tasks.");
        }
    }
    
    public void populateTestData() {
        addTask("Mike Smith", "Create Login", 5, "To Do");
        addTask("Edward Harrison", "Create Add Features", 8, "Doing");
        addTask("Samantha Paulson", "Create Reports", 2, "Done");
    }
    
    public void displayTaskswithStatusDone() {
        for (int i = 0; i < taskCount; i++) {
            if ("Done".equals(taskStatuses[i])) {
                System.out.println("Developer: " + developers[i]);
                System.out.println("Task Name: " + taskNames[i]);
                System.out.println("Duration: " + taskDurations[i] + " hours");
            }
        }
    }
    public void displayLongestTask() {
        int maxIndex = 0;
        for(int i = 1;i < taskCount; i++) {
            if (taskDurations[i] > taskDurations[maxIndex]) {
                maxIndex = i;
            }
        }
        System.out.println("Developer: " + developers[maxIndex]);
        System.out.println("Duration: " + taskDurations[maxIndex] + " hours");
    }
    public String searchTaskByName(String taskName) {
       for (int i = 0; i < taskCount; i++) {
        if (taskName.equals(taskNames[i])) {
            // Task found, return the formatted string with task details
            return "Task Name: " + taskNames[i] + "\nDeveloper: " + developers[i] + "\nStatus: " + taskStatuses[i] + "\n";
        }
    }
    // Task not found, return the "Task not found" message
    return "Task not found.";
    }
    public void searchTasksByDeveloper(String developer) {
        for (int i = 0; i < taskCount; i++) {
            if (developer.equals(developers[i])) {
            System.out.println("Task Name: " + taskNames[i]);
            System.out.println("Status" + taskStatuses[i]);
        }
        }
    }
    public void deleteTaskNameByname(String taskName) {
        for (int i = 0; i < taskCount; i++) {
        if (taskName.equals(taskNames[i])) {
            // Shift tasks to the left
            for (int j = i; j < taskCount - 1; j++) {
                developers[j] = developers[j + 1];
                taskNames[j] = taskNames[j + 1];
                taskIDs[j] = taskIDs[j + 1];
                taskDurations[j] = taskDurations[j + 1];
                taskStatuses[j] = taskStatuses[j + 1];
            }
            // Clear the last position
            developers[taskCount - 1] = null;
            taskNames[taskCount - 1] = null;
            taskIDs[taskCount - 1] = null;
            taskDurations[taskCount - 1] = 0;
            taskStatuses[taskCount - 1] = null;

            taskCount--;
            System.out.println("Task deleted successfully!");
            return;
        }
    }
    System.out.println("Task not found.");
}
    public void displayTaskReport() {
        for (int i = 0; i < taskCount; i++) {
            System.out.println("Task ID: " + taskIDs[i]);
            System.out.println("Developer: " + developers[i]);
            System.out.println("Task Name: " + taskNames[i]);
            System.out.println("Duration: " + taskDurations[i] + " hours");
            System.out.println("Status: " + taskStatuses[i]);
            System.out.println("---------------------------");
        }
    }
    // Main method
    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();

        // Add tasks
        taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");
        taskManager.addTask("Edward Harrison", "Create Add Features", 8, "Doing");
        taskManager.addTask("Samantha Paulson", "Create Reports", 2, "Done");

        // Display tasks
        System.out.println("All Tasks:");
        taskManager.displayTaskReport();

        // Search for a specific task
        System.out.println("\nSearching for 'Create Add Features':");
        System.out.println(taskManager.searchTaskByName("Create Add Features"));

        // Display the longest task
        System.out.println("\nLongest Task:");
        taskManager.displayLongestTask();

        // Delete a task
        System.out.println("\nDeleting 'Create Add Features':");
        taskManager.deleteTaskNameByname("Create Add Features");

        // Display tasks after deletion
        System.out.println("\nAll Tasks After Deletion:");
        taskManager.displayTaskReport();
    }
  }
   