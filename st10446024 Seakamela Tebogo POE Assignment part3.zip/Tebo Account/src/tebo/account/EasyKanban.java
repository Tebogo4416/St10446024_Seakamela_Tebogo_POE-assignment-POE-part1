
package tebo.account;
import javax.swing.JOptionPane;
import java.util.ArrayList;


public class EasyKanban {
    // List to keep track of all duties
    private static ArrayList<Tasks> tasks = new ArrayList<>();
    
    public static void main(String[] args) {
        // Call the Login class logic or simulate a successful login.
        boolean isLoggedIn = true;
        
        if (!isLoggedIn) {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting...");
            System.exit(0);
        }
        
        JOptionPane.showMessageDialog(null, "Welcome to EasyKnaban!");
        
        while (true) {
            String option = JOptionPane.showInputDialog("Select an option:\n1) Add tasks\n2) Show report\n3) Quit");
            
            switch (option) {
                case "1" -> addTasks();
                case "2" -> JOptionPane.showMessageDialog(null, "Coming Soon");
                case "3" -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option. Try again.");
            }
        }
    }
    
    // How to use a loop to add tasks
    private static void addTasks() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("How many tasks would you like to add?"));
        
        int totalHours = 0;
        
        // Loop to add more than one task
        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name:");
            String taskDescription = JOptionPane.showInputDialog("Enter task description:");
            
            // Verify that the task description is more than fifty characters.
            if (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Task description must be 50 characters or less.");
                i--; // Try the current task again
                continue;
            }
            
            String developer = JOptionPane.showInputDialog("Enter developer's name(First Last):");
            int duration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration in hours:"));
            String status = JOptionPane.showInputDialog("Enter task status(To do, Done, Doing):");
            
            // Add a new task to the list after creating it.
            Tasks task = new Tasks(taskName, i, taskDescription, developer,duration,status);
            
            // Show the task details.
            JOptionPane.showMessageDialog(null, task.printTaskDetails());
            
            // Compute the total number of hours.
            totalHours += task.getTaskDuration();
        }
        // List all of the tasks' combined hours.
        JOptionPane.showMessageDialog(null, "Total hours for all tasks:" + totalHours);
    }
}
