
package tebo.account;
import java.util.Scanner;

public class Login {
    // Procedure for verifying the validity of the username
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    
    // Procedure for verifying the validity of the username
    public boolean verifyUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }
    
    public boolean verifyPasswordComplexity(String password) {
        return password.length() >= 8 && // A minimum of 8 characters
               password.matches(".*[A-Z].*") && //A minimum of one capital letter
               password.matches(".*[0-9].*") && // At least one digit
               password.matches(".*[@#$%^&+=!].*"); // A minimum of one unique character
        
    }
   
    // How to register a user
    public String enrollUser(String username, String password, String firstName, String lastName) {
        if (!verifyUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        }
        if (!verifyPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        }
        
        // Save the user's data if the username and password are both legitimate.
        this.username = username;
        this.password = password;
        this.firstName = firstName;
        this.lastName = lastName;       
        return "User registered successfully!";
    }
    // How to log a user in
    public boolean loginUser(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }
      // Method to return the login status message
    public String returnLoginStatus(boolean isLoggedIn) {
        if (isLoggedIn) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again!";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
    // How to retrieve the notification about the login status
        public static void main(String[] args) {
            Login loginSystem = new Login();
            Scanner scanner = new Scanner(System.in);
            
            System.out.println("Welcome to the registration system!");
            
            // Registration Process
            System.out.println("Enter username: ");
            String username = scanner.nextLine();
            System.out.println("Enter password: ");
            String password = scanner.nextLine();
            System.out.println("Enter first name:  ");
            String firstName = scanner.nextLine();
            System.out.println("Enter last name:  ");
            String lastName = scanner.nextLine();
            
            // Procedure for registration
            String registrationMessage = loginSystem.enrollUser(username, password, firstName, lastName);
            System.out.println(registrationMessage);
            
            //Go to the login page if your registration was accepted.
            if (registrationMessage.equals("User registered successfully!")){
                System.out.println("\nNow, please log in.");
                
                System.out.println("Enter username: ");
                String loginUsername = scanner.nextLine();
                System.out.println("Enter password: ");
                String loginPassword = scanner.nextLine();
                
                boolean loginSuccessful = loginSystem.loginUser(loginUsername, loginPassword);
                System.out.println(loginSystem.returnLoginStatus(loginSuccessful));
            } 
    }
    
}
