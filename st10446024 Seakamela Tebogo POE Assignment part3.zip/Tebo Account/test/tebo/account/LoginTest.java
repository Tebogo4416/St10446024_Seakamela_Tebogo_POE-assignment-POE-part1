
package tebo.account;

import org.junit.Test;
import static org.junit.Assert.*;


public class LoginTest {
    
    public LoginTest() {
    }
//Test the Login ClasstestVerifyUserName function.
    @Test
    public void testVerifyUserName() {
        // To test, create an instance of the Login class.
        Login login = new Login();
        
        // Verify the username is valid. (should return true)
        assertTrue(login.verifyUserName("T_ebo")); //Anticipated outcome: true
        
        //Test invalid usernames (should return false)
        assertFalse(login.verifyUserName("Tebo")); //Absent underscore,should return false
        assertFalse(login.verifyUserName("Tebo")); // To little, should return false
        assertFalse(login.verifyUserName("Tebo_seakamela")); //More than 5 characters, should return
    }
// Test the login class's verifyPasswordComplexity function.
    @Test
    public void testVerifyPasswordComplexity() {
        // To test, create an instance of the Login class.
        Login login = new Login();
        
        //Test valid password (Should return true)
        assertTrue(login.verifyPasswordComplexity("Qwert12#")); //Meet all condditions
        
        // Check if a password is invalid (Should return false)
        assertFalse(login.verifyPasswordComplexity("qwer")); // Too short, no capital
        assertFalse(login.verifyPasswordComplexity("Qwer")); // No number, no special character
        assertFalse(login.verifyPasswordComplexity("Qwer1")); // No special character
        
    }
//Examine the EnrollUser function found in login class.
    @Test
    public void testEnrollUser() {
        //To test create an instance of the Login class.
        Login login = new Login();
        
        //Verify the registration's validity (should return success message)
        String result = login.enrollUser("T_ebo", "Qwert12#", "Tebogo", "Seakamela");
        System.out.println("Result: " + result); // Print the result
        assertEquals("User registered successfully!", result);
        
        // Test invalid username (Should return username error message)
        result = login.enrollUser("Tebo", "Qwert12#", "Tebogo", "Seakamela");
        System.out.println("Result: " + result); // Print the result
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.", result);
        
        //Test invalid password (should return password error message)
        result = login.enrollUser("T_ebo", "qwer", "Tebogo", "Seakamela");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.", result);

    }
    
// Test the LoginUser method from the login class.
    @Test
    public void testLoginUser() {
        //Make a user account and create an instance of the login class.
        Login login = new Login();
        login.enrollUser("T_ebo", "Qwert12#", "Tebogo", "Seakamela");
        
        //Verify the successful login. (Should return true)
        assertTrue(login.loginUser("T_ebo", "Qwert12#"));
        
        //Test failed login (wrong password, should return false)
        assertFalse(login.loginUser("T_ebo", "Qwer"));
        
        //Test failed login (wrong ussername, should return false)
        assertFalse(login.loginUser("Tebo", "Qwert12#"));
    }

    //Test the Login class returnLoginStatus function.
    @Test
    public void testReturnLoginStatus() {
        //Make a user account and create an instance of the Login class.
        Login login = new Login();
        login.enrollUser("T_ebo", "Qwert12#", "Tebogo", "Seakamela");
        
        // Verify the successful login status message
        String result = login.returnLoginStatus(true);
        
        //Print thee actual result to see if there's any difference
        System.out.println("Actual result:" + result);
        
        // Test failed login status message
       
        assertEquals("Welcome Tebogo Seakamela, it is great to see you again!", result);
    }

    @Test
    public void testMain() {
        
    }
    
}
