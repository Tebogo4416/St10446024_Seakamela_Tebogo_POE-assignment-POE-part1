
package tebo.account;


import org.junit.Test;
import static org.junit.Assert.*;


public class TaskManagerTest {
    
    public TaskManagerTest() {
    }

    @Test
    public void testAddTask() {
        TaskManager taskManager = new TaskManager();

        taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");

        // Assert that the task details were added correctly
        assertEquals("Mike Smith", taskManager.getDevelopers()[0]);
        assertEquals("Create Login", taskManager.getTaskNames()[0]);
        assertEquals(5, taskManager.getTaskDurations()[0]);
        assertEquals("To Do", taskManager.getTaskStatuses()[0]);
        assertEquals("CR:0:ITH", taskManager.getTaskIDs()[0]); // Verify TaskID format
    }

    @Test
    public void testDisplayTaskswithStatusDone() {
        TaskManager taskManager = new TaskManager();
        
        taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");
        taskManager.addTask("Samantha Paulson", "Create Reports", 2, "Done");
        
        try { 
            taskManager.displayTaskswithStatusDone();
        } catch (Exception e) {
            fail("Method threw an exception: " +e.getMessage());
        }
        
    }

    @Test
    public void testDisplayLongestTask() {
         TaskManager taskManager = new TaskManager();

    taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");
    taskManager.addTask("Edward Harrison", "Create Add Features", 8, "Doing");

    try{
        taskManager.displayLongestTask();
    } catch (Exception e) {
        fail("Method threw an exception: " + e.getMessage());
    }
    }

    @Test
    public void testSearchTaskByName() {
        TaskManager taskManager = new TaskManager();

    taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");
    taskManager.addTask("Edward Harrison", "Create Add Features", 8, "Doing");

      String result = taskManager.searchTaskByName("Create Login");
    String expectedOutput = "Task Name: Create Login\nDeveloper: Mike Smith\nStatus: To Do\n";

    assertEquals(expectedOutput, result);
    }

    @Test
    public void testSearchTasksByDeveloper() {
    }

    @Test
    public void testdeleteTaskNameByname() {
         TaskManager taskManager = new TaskManager();

        // Add tasks
        taskManager.addTask("Mike Smith", "Create Login", 5, "To Do");
        taskManager.addTask("Edward Harrison", "Create Add Features", 8, "Doing");

        // Delete the second task
        taskManager.deleteTaskNameByname("Create Add Features");

        // Verify the task has been deleted
        assertNull(taskManager.getTaskNames()[1]); // Ensure the second task is null
        assertEquals(1, taskManager.getTaskCount()); // Ensure task count is reduced
        assertEquals("Create Login", taskManager.getTaskNames()[0]); // First task remains
    }

    @Test
    public void testDisplayTaskReport() {
    }

    @Test
    public void testGetDevelopers() {
    }

    @Test
    public void testGetTaskNames() {
    }

    @Test
    public void testGetTaskIDs() {
    }

    @Test
    public void testGetTaskDurations() {
    }

    @Test
    public void testGetTaskStatuses() {
    }

    @Test
    public void testGetTaskCount() {
    }

    @Test
    public void testPopulateTestData() {
    }

    
    
}
