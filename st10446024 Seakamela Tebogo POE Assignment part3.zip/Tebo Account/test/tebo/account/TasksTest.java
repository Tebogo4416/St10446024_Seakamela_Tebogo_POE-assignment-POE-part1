
package tebo.account;

import org.junit.Test;
import static org.junit.Assert.*;


public class TasksTest {
    
    public TasksTest() {
    }

    @Test
    public void testCheckTaskDescription() {
        Tasks task = new Tasks("Feature", 1, "This is a valid description", "Mike Smith", 5, "Doing");
        assertTrue(task.checkTaskDescription());
        
        Tasks invalidTask = new Tasks("Feature", 2, "This description exceedds fifty characters and should fail.", "Test User", 5, "To Do");
        assertFalse(invalidTask.checkTaskDescription());
    }

    @Test
    public void testCreateTaskID() {
        Tasks task = new Tasks("Login feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        
        //  Expected Task ID: LO:0:SON
        assertEquals("LO:0:SON", task.createTaskID());
    }

    @Test
    public void testPrintTaskDetails() {
    }

    @Test
    public void testGetTaskDuration() {
        Tasks task1 = new Tasks("Login Feature", 0, "Create Login to authenticate users", "Robyn Harrison", 8, "To Do");
        Tasks task2 = new Tasks("Add Feature", 1, "Create Add Feature functionality", "Mike Smith", 10, "Doing");
        
        int totalHours = task1.getTaskDuration() + task2.getTaskDuration();
        assertEquals(18, totalHours);
    }
    
}
